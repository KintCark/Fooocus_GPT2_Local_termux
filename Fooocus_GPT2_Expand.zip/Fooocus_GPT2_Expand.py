import sys
from transformers import AutoModelForCausalLM, AutoTokenizer

# 1. Check if a prompt was provided via command line
if len(sys.argv) < 2:
    print("Usage: python3 Fooocus_GPT2.py 'your prompt here'")
    sys.exit(1)

user_prompt = sys.argv[1]
print(f"Loading model for prompt: '{user_prompt}'...")

# 2. Load tokenizer and model
model_id = "LykosAI/GPT-Prompt-Expansion-Fooocus-v2"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id, device_map="cpu")

# 3. Tokenize input prompt
inputs = tokenizer(user_prompt, return_tensors="pt")

# 4. Generate expanded prompt text
outputs = model.generate(
    inputs["input_ids"],
    max_length=75,
    do_sample=True,
    temperature=0.7,
    top_p=0.9,
    pad_token_id=tokenizer.eos_token_id
)

# 5. Decode and print result
expanded_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
print("\n--- Expanded Prompt ---")
print(expanded_text)
